FOOTBALL ANALYSIS GIANT V2.30 — AUTO ELITE DASHBOARD

V2.30 builds on V2.29.

Main fix:
Elite Dashboard statistics now recalculate automatically whenever match data
changes, when the app regains focus, when the tab becomes visible, and on a
short periodic safety refresh.

Today's metrics:
- TODAY = today's Elite records
- COMPLETED = today's completed records
- CORRECT = today's WON records
- ACCURACY = CORRECT / COMPLETED

The Giant remains the source for Elite analysis.
Mini remains separate and receives only explicitly shared records.

No old localStorage data is intentionally deleted.
